package com.escalab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TareaUnoModelApplication {

	public static void main(String[] args) {
		SpringApplication.run(TareaUnoModelApplication.class, args);
	}

}
