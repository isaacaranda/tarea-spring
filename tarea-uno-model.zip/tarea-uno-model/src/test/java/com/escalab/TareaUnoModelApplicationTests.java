package com.escalab;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TareaUnoModelApplicationTests {

	void contextLoads() {
	}

}
